package JSONintoDB.jsonintodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsonintodbApplication {

	public static void main(String[] args) {
		SpringApplication.run(JsonintodbApplication.class, args);
	}

}
